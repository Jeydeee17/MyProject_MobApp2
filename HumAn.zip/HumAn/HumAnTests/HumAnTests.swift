//
//  HumAnTests.swift
//  HumAnTests
//
//  Created by Extra User on 12/5/24.
//

import Testing
@testable import HumAn

struct HumAnTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
