//
//  ViewController.swift
//  HumAn
//
//  Created by Extra User on 12/5/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

