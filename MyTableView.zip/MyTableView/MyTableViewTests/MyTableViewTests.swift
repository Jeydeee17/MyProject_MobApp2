//
//  MyTableViewTests.swift
//  MyTableViewTests
//
//  Created by Extra User on 12/4/24.
//

import Testing
@testable import MyTableView

struct MyTableViewTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
