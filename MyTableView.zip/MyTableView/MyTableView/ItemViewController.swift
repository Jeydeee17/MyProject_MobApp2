//
//  ItemViewController.swift
//  MyTableView
//
//  Created by Jenette J. Balbuena on 12/4/24.
//

import UIKit

class ItemViewController: UIViewController {
    
    var sendItem:Item?
    
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var itemDescription: UILabel!
    @IBOutlet weak var itemPrice: UILabel!
    @IBOutlet weak var itemImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let item = sendItem {
            print("Received item: \(item.name)")

            if let nameLabel = itemName {
                nameLabel.text = item.name
            } else {
                print("itemName is nil!")
            }

            if let descriptionLabel = itemDescription {
                descriptionLabel.text = item.desc
            } else {
                print("itemDescription is nil!")
            }

            if let priceLabel = itemPrice {
                priceLabel.text = String(format: "%.2f", item.price)
            } else {
                print("itemPrice is nil!")
            }

            if let imageView = itemImage {
                imageView.image = UIImage(named: item.imageFile)
            } else {
                print("itemImage is nil!")
            }
        } else {
            print("sendItem is nil!")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
