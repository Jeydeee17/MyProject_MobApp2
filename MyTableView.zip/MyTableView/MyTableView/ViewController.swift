//
//  ViewController.swift
//  MyTableView
//
//  Created by Extra User on 12/4/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

